#!/usr/bin/env python3

from brain_games.even_game import start_game as start_game


def main():
    start_game()


if __name__ == '__main__':
    main()
