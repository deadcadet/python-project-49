from brain_games.scripts.game_functions import welcome_user as welcome_user


def main():
    welcome_user()


if __name__ == '__main__':
    main()
