from brain_games.scripts.game_functions import play_game as play_game


def main():
    play_game('calc')


if __name__ == '__main__':
    main()
