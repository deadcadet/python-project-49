### Hexlet tests and linter status:
[![Actions Status](https://github.com/deadcadet/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/deadcadet/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/b397fecb326f90c3153c/maintainability)](https://codeclimate.com/github/deadcadet/python-project-49/maintainability)

install demonstration:
[![asciicast](https://asciinema.org/a/RZFrK5pUZ99WMmPTnsG6mygbc.svg)](https://asciinema.org/a/RZFrK5pUZ99WMmPTnsG6mygbc)

brain-games demonstration:
[![asciicast](https://asciinema.org/a/WWCf4yn3OYxwAJeZZr5ZTcbYp.svg)](https://asciinema.org/a/WWCf4yn3OYxwAJeZZr5ZTcbYp)

brain-calc demonstration:
[![asciicast](https://asciinema.org/a/jwhal01UrcemQna5HUIjzgAXO.svg)](https://asciinema.org/a/jwhal01UrcemQna5HUIjzgAXO)

brain-even demonstration:
[![asciicast](https://asciinema.org/a/8wN2BA2AhKYLCsoYcNVydOuyp.svg)](https://asciinema.org/a/8wN2BA2AhKYLCsoYcNVydOuyp)

brain-gcd demonstration:
[![asciicast](https://asciinema.org/a/26r0VBJT4PNEbLhLx1kpq4kNP.svg)](https://asciinema.org/a/26r0VBJT4PNEbLhLx1kpq4kNP)

brain-progression demonstration:
[![asciicast](https://asciinema.org/a/7rYjQsQq8GKivya3l0wcp6o19.svg)](https://asciinema.org/a/7rYjQsQq8GKivya3l0wcp6o19)