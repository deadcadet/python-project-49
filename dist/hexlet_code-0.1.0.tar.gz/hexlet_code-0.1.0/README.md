### Hexlet tests and linter status:
[![Actions Status](https://github.com/deadcadet/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/deadcadet/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/b397fecb326f90c3153c/maintainability)](https://codeclimate.com/github/deadcadet/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/nfHD60svlBgw8aCmA8Dw8sQtl.svg)](https://asciinema.org/a/nfHD60svlBgw8aCmA8Dw8sQtl)