from brain_games.scripts.game_functions import play_game as play_game
from brain_games.scripts.game_functions import get_question_calc as get_question_calc  # noqa E501


def main():
    play_game('calc')


if __name__ == '__main__':
    main()
